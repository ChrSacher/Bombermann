/**
 * Art des Power Ups
 * 
 * @author Dieu Huyen Dinh
 * @version 6.12.17
 */
public enum PowerUpType
{
    Speed,
    Strength,
    Ammount,
    Death;
    
}