/**
 * Spieler Farben die zur Verfügung stehen
 * 
 * @author Christian Sacher
 * @version 11.12.2017
 */
public enum PlayerColor
{ 
   White,
   Black,
   Blue,
   Red
}