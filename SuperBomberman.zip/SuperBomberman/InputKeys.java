/**
 * Enum für alle Funktionen die ein Bomberman Spieler braucht
 * 
 * @author Christian Sacher
 * @version 11.12.2017
 */
public enum InputKeys
{
    Up,
    Down,
    Left,
    Right,
    ThrowBomb
    
}