/**
 * Bewegungsrichtung
 * 
 * @author Dieu Huyen Dinh
 * @version 7.13.17
 */
public enum MovementDirection
{ 
    Up,
    Down,
    Left,
    Right
}